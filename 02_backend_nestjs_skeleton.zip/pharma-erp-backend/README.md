# Pharma ERP Backend

Squelette NestJS pour ERP Pharmaceutique SaaS V2.

## Modules principaux

- Auth / Tenants / Users / Roles / Permissions
- Articles / Achats / Lots / Stocks
- Ventes POS / Paiements / Caisse
- Assurances / Créances
- Comptabilité / Reporting BI

## Démarrage

```bash
npm install
cp .env.example .env
npm run start:dev
```

Swagger local :

```text
http://localhost:3000/docs
```

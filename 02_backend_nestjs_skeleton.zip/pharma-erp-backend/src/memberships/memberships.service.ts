import { Injectable } from '@nestjs/common';
import { MembershipsRepository } from './memberships.repository';

@Injectable()
export class MembershipsService {
  constructor(private readonly repository: MembershipsRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

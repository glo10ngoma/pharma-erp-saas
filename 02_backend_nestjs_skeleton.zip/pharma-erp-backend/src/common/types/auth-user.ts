export type AuthUser = {
  userId: string;
  tenantId: string;
  siteId?: string;
  role: string;
  permissions: string[];
};

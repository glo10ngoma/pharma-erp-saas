import { Injectable } from '@nestjs/common';
import { SitesRepository } from './sites.repository';

@Injectable()
export class SitesService {
  constructor(private readonly repository: SitesRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { RequirePermission } from '../common/decorators/require-permission.decorator';
import { LotsService } from './lots.service';

@ApiTags('lots')
@ApiBearerAuth()
@Controller('lots')
export class LotsController {
  constructor(private readonly service: LotsService) {}

  @Get()
  @RequirePermission('lots.read')
  findAll() {
    return this.service.findAll();
  }
}

import { Injectable } from '@nestjs/common';
import { LotsRepository } from './lots.repository';

@Injectable()
export class LotsService {
  constructor(private readonly repository: LotsRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

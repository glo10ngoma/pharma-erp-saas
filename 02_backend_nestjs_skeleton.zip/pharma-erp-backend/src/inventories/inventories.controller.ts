import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { RequirePermission } from '../common/decorators/require-permission.decorator';
import { InventoriesService } from './inventories.service';

@ApiTags('inventories')
@ApiBearerAuth()
@Controller('inventories')
export class InventoriesController {
  constructor(private readonly service: InventoriesService) {}

  @Get()
  @RequirePermission('inventories.read')
  findAll() {
    return this.service.findAll();
  }
}

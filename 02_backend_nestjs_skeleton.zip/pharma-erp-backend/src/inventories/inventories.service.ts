import { Injectable } from '@nestjs/common';
import { InventoriesRepository } from './inventories.repository';

@Injectable()
export class InventoriesService {
  constructor(private readonly repository: InventoriesRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

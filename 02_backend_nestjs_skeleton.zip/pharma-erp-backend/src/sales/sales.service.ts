import { Injectable } from '@nestjs/common';
import { SalesRepository } from './sales.repository';

@Injectable()
export class SalesService {
  constructor(private readonly repository: SalesRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

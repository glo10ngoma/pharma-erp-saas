import { IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateSaleDto {
  @IsUUID()
  siteId: string;

  @IsOptional()
  @IsUUID()
  customerId?: string;

  @IsUUID()
  currencyId: string;

  @IsEnum(['CASH', 'CUSTOMER_CREDIT', 'ORGANIZATION_CREDIT', 'INSURANCE'])
  saleType: 'CASH' | 'CUSTOMER_CREDIT' | 'ORGANIZATION_CREDIT' | 'INSURANCE';
}

import { Injectable } from '@nestjs/common';
import { StocksRepository } from './stocks.repository';

@Injectable()
export class StocksService {
  constructor(private readonly repository: StocksRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

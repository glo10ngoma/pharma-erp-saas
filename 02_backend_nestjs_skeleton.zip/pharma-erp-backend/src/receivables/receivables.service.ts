import { Injectable } from '@nestjs/common';
import { ReceivablesRepository } from './receivables.repository';

@Injectable()
export class ReceivablesService {
  constructor(private readonly repository: ReceivablesRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

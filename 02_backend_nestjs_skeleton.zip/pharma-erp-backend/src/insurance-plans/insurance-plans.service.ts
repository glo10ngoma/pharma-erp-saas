import { Injectable } from '@nestjs/common';
import { InsurancePlansRepository } from './insurance-plans.repository';

@Injectable()
export class InsurancePlansService {
  constructor(private readonly repository: InsurancePlansRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

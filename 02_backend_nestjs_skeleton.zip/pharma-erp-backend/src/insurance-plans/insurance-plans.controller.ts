import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { RequirePermission } from '../common/decorators/require-permission.decorator';
import { InsurancePlansService } from './insurance-plans.service';

@ApiTags('insurance-plans')
@ApiBearerAuth()
@Controller('insurance-plans')
export class InsurancePlansController {
  constructor(private readonly service: InsurancePlansService) {}

  @Get()
  @RequirePermission('insurance-plans.read')
  findAll() {
    return this.service.findAll();
  }
}

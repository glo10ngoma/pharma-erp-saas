import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { ArticlesModule } from './articles/articles.module';
import { PurchasesModule } from './purchases/purchases.module';
import { SalesModule } from './sales/sales.module';
import { StocksModule } from './stocks/stocks.module';
import { CashModule } from './cash/cash.module';
import { ReportsModule } from './reports/reports.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    AuthModule,
    ArticlesModule,
    PurchasesModule,
    SalesModule,
    StocksModule,
    CashModule,
    ReportsModule,
  ],
})
export class AppModule {}

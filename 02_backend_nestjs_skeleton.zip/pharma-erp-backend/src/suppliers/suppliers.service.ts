import { Injectable } from '@nestjs/common';
import { SuppliersRepository } from './suppliers.repository';

@Injectable()
export class SuppliersService {
  constructor(private readonly repository: SuppliersRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

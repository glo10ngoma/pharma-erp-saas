import { Injectable } from '@nestjs/common';
import { StockMovementsRepository } from './stock-movements.repository';

@Injectable()
export class StockMovementsService {
  constructor(private readonly repository: StockMovementsRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

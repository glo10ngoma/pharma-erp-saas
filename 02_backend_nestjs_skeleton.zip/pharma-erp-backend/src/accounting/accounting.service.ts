import { Injectable } from '@nestjs/common';
import { AccountingRepository } from './accounting.repository';

@Injectable()
export class AccountingService {
  constructor(private readonly repository: AccountingRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

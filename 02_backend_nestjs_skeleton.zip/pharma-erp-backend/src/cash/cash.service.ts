import { Injectable } from '@nestjs/common';
import { CashRepository } from './cash.repository';

@Injectable()
export class CashService {
  constructor(private readonly repository: CashRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { RequirePermission } from '../common/decorators/require-permission.decorator';
import { CashService } from './cash.service';

@ApiTags('cash')
@ApiBearerAuth()
@Controller('cash')
export class CashController {
  constructor(private readonly service: CashService) {}

  @Get()
  @RequirePermission('cash.read')
  findAll() {
    return this.service.findAll();
  }
}

import { Injectable } from '@nestjs/common';
import { ArticlesRepository } from './articles.repository';

@Injectable()
export class ArticlesService {
  constructor(private readonly repository: ArticlesRepository) {}

  findAll() {
    return this.repository.findAll();
  }
}

import { Link, Outlet } from 'react-router-dom';

export function DashboardLayout() {
  return (
    <div className="layout">
      <aside className="sidebar">
        <h2>PharmaERP</h2>
        <nav style={{ display: 'grid', gap: 12 }}>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/articles">Articles</Link>
          <Link to="/pos">Vente POS</Link>
          <Link to="/stocks">Stocks</Link>
          <Link to="/purchases">Achats</Link>
          <Link to="/cash">Caisse</Link>
          <Link to="/reports">Rapports</Link>
        </nav>
      </aside>
      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}

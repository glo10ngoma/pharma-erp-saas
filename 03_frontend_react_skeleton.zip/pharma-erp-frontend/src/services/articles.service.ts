import { apiClient } from './apiClient';

export const articlesService = {
  getAll: (params?: Record<string, unknown>) =>
    apiClient.get('/articles', { params }),

  getById: (id: string) =>
    apiClient.get(`/articles/${id}`),
};

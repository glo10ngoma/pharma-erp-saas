export function DashboardPage() {
  return (
    <>
      <h1>Dashboard</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        <div className="card"><strong>CA Jour</strong><h2>0 USD</h2></div>
        <div className="card"><strong>CA Mois</strong><h2>0 USD</h2></div>
        <div className="card"><strong>Stock</strong><h2>0 USD</h2></div>
        <div className="card"><strong>Créances</strong><h2>0 USD</h2></div>
      </div>
      <div className="card">Graphique ventes à intégrer</div>
    </>
  );
}

export function LoginPage() {
  return (
    <div style={{ maxWidth: 420, margin: '80px auto' }} className="card">
      <h1>PharmaERP SaaS</h1>
      <p>Connexion utilisateur</p>
      <input className="input" placeholder="Email" />
      <br /><br />
      <input className="input" placeholder="Mot de passe" type="password" />
      <br /><br />
      <button className="button">Se connecter</button>
    </div>
  );
}

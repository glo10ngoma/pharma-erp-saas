import { useQuery } from '@tanstack/react-query';
import { articlesService } from '../../services/articles.service';

export function ArticlesPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['articles'],
    queryFn: async () => {
      const res = await articlesService.getAll();
      return res.data.data;
    },
  });

  return (
    <>
      <h1>Articles</h1>
      <div className="card">
        <input className="input" placeholder="Recherche article, DCI ou code-barres" />
      </div>
      <div className="card">
        {isLoading ? 'Chargement...' : 'Table articles à intégrer'}
        <pre>{JSON.stringify(data, null, 2)}</pre>
      </div>
    </>
  );
}

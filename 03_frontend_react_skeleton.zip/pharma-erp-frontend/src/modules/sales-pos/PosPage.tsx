export function PosPage() {
  return (
    <>
      <h1>Vente POS</h1>
      <div className="card">
        <input className="input" placeholder="Scanner code-barres / rechercher produit" />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="card">
          <h3>Produits</h3>
          Résultats recherche
        </div>
        <div className="card">
          <h3>Panier</h3>
          Produit | Qté | PU | Total
        </div>
      </div>
      <div className="card">
        <h3>Paiement</h3>
        <button className="button">Valider la vente</button>
      </div>
    </>
  );
}
